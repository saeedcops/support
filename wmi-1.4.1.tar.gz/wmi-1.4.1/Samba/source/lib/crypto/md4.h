void mdfour(uint8_t *out, const uint8_t *in, int n);
